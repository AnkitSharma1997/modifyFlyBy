package com.cts.repository;

import javax.persistence.Query;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.entity.User;
import com.cts.exception.UserException;

@Repository
public class UserDaoImpl implements UserDao {

//	@Autowired
//	private EntityManager manager;
	
	@Autowired
	private SessionFactory sessionfactory;
	
	public boolean saveUser(User user) throws UserException{
		// TODO Auto-generated method stub
		System.out.println("\t # \t saveUser mehtod");
		
		Session session  = sessionfactory.openSession();
		Transaction tx = session.beginTransaction();
		boolean flag =true;
		User current_user = checkUserNameAndEmail(user);
		System.out.println("\t # current_user\t"+current_user);
			if(current_user!=null) {
				if(current_user.getUserName().equalsIgnoreCase(user.getUserName())) {
					flag = false;
					throw new UserException("UserName already Exists");
				}
				else if(current_user.getEmail().equalsIgnoreCase(user.getEmail())) {
					flag = false;
					throw new UserException("Email already exists");
				}
			}
			else {
			session.persist(user);
			tx.commit();
			session.close();
			
			}
		
		return flag;
	}

	@Override
	public boolean deleteUser(int userId) {
		// TODO Auto-generated method stub
		Session session = sessionfactory.getCurrentSession();
		User user = getUserDetails(userId);
		System.out.println("deleting User :" + user);
		session.delete(user);
		return true;
	}

	@Override
	public boolean updateUser(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public User getUserDetails(int userId) {
		// TODO Auto-generated method stub
		Session session = sessionfactory.openSession();
//		Query query=session.createNamedQuery("getUserDetail");
//		query.setParameter("Id", userId);
		System.out.println("userId getUserDetails userDaoImpl\t"+userId);
		User user = (User) session.get(User.class, userId);
		
//		session.close();
		return user;
	}




	@Override
	public User checkUserNameAndEmail(User user){
		System.out.println("\t # \t checkUserNameAndEmail mehtod");
		Session session = sessionfactory.openSession();
		System.out.println("\t username:"+user.getUserName()+"\t email:"+user.getEmail());
		User existedUser=null;
		try {
		String userNameEmail = "from User where userName=:userName or email=:email";
		Query checkUserNameAndEmail = session.createQuery(userNameEmail);
		checkUserNameAndEmail.setParameter("userName", user.getUserName());
		checkUserNameAndEmail.setParameter("email", user.getEmail());
		System.out.println("\t # \t checkUserNameAndEmail query");
		
		
		existedUser = (User) checkUserNameAndEmail.getSingleResult();
		System.out.println("\t # \t checkUserNameAndEmail query   22222222");
		}catch(Exception e) {
			System.out.println("UserDao Imol checkUserNameANdEmail   \t"+e.getMessage());
		}
		
		return existedUser;
	}

	@Override
	public User checkUserCredentials(User user) {
		// TODO Auto-generated method stub
		Session session = sessionfactory.getCurrentSession();
		User querryUser=null;
		System.out.println("\t\tuser Credentilas userDaoImpl");
		try {
		String userNamePassword = "from User where userName=:userName and password=:password";
		Query query=session.createQuery(userNamePassword);
		query.setParameter("userName", user.getUserName());
		query.setParameter("password", user.getPassword());
		
		 
		querryUser = (User) query.getSingleResult();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		return querryUser;
	}
	
	

}
