package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.Flight;
import com.cts.entity.Passenger;
import com.cts.exception.BookingException;
import com.cts.modal.FlightSearch;
import com.cts.repository.BookingDao;

@Service
public class BookingImpl implements Booking {
	@Autowired
	private BookingDao bookingDao;
	@Override
	public String bookingFlight(Passenger passenger, int flightId, int noOfPassengers){
		// TODO Auto-generated method stub
	   boolean flag = false;
	   String message;
	   try{
		   flag = bookingDao.bookingFlight(passenger, flightId, noOfPassengers);
	   }catch(BookingException e){
		   message = e.getMessage();
			System.out.println(e.getMessage()+"\t BookingServiceImpl meassage \t"+message);
			if(!flag)
				return message;
	   }
		return null;
	}
	@Override
	public boolean saveFlight(Flight flight) {
		// TODO Auto-generated method stub
		return bookingDao.saveFlight(flight);
	}

	@Override
	public List<Passenger> bookingHistory(int userId) {
		// TODO Auto-generated method stub
		
		return bookingDao.bookingHistory(userId);
	}
	@Override
	public List<Flight> searchCorrespondingFlights(FlightSearch searchObject) {
		// TODO Auto-generated method stub
		String[] formattedDateOfJourney = searchObject.getDateOfJournay().split("-");
		StringBuffer sb = new StringBuffer();
		sb = sb.append(formattedDateOfJourney[2]).append("-").append(formattedDateOfJourney[1]).append("-").append(formattedDateOfJourney[0]);
		searchObject.setDateOfJournay(sb.toString());
		return bookingDao.searchCorrespondingFlights(searchObject);
	}
	
	

}
