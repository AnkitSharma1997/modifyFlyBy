package com.cts.service;

import java.util.List;

import com.cts.entity.Flight;
import com.cts.entity.Passenger;
import com.cts.exception.BookingException;
import com.cts.modal.FlightSearch;

public interface Booking {

	public String bookingFlight(Passenger passenger, int flightId ,int noOfPassengers);
	public List<Passenger> bookingHistory(int userId);
	public List<Flight> searchCorrespondingFlights(FlightSearch searchObject);
	boolean saveFlight(Flight flight);
}
