package com.cts.exception;

public class BookingException extends Exception{

	public BookingException(String message) {
		super(message);
	}
}
